# Testrep
Cloning with HTTPS URLs The https:// clone URLs are available on all repositories, regardless of visibility. https:// clone URLs work even if you are behind a firewall or proxy
It worked and  you only needed to add  the speech marks.
Keep testing and working  on it
It worked succesffuly
It was a  nice   ride and  try
